# Backend Integration Guide — ML Model Service

**Message to send your backend engineer, verbatim:**

> "I've packaged all our ML models behind a REST API (`app.py`, FastAPI). You don't need Python or any ML library knowledge — just call these HTTP endpoints from our backend like any other microservice. Run `pip install -r requirements.txt` then `uvicorn app:app --host 0.0.0.0 --port 8000` to start it. Full interactive docs (test every endpoint from the browser) will be live at `http://localhost:8000/docs` once it's running. Below is exactly what to send and what you'll get back for each endpoint."

---

## Architecture decision — why a separate service, not embedded code

Your backend (Node.js/whatever it's in) should call this ML service **over HTTP**, not import Python code directly. Reasons:
- Your models are scikit-learn (Python-only) — there's no way to run them natively inside a Node.js/Java backend.
- Decouples deploy cycles: ML engineer can update/retrain a model and restart just this service without touching the main backend.
- This is the standard "model-as-a-microservice" pattern used in production ML systems.

```
┌─────────────────┐      HTTP/JSON      ┌──────────────────────┐
│  Main Backend    │  ───────────────►  │  ML Inference Service │
│  (Node/Java/etc) │  ◄───────────────  │  (this app.py, :8000)  │
└─────────────────┘                     └──────────────────────┘
```

Deploy this as its own container/process, reachable from the backend on an internal URL (e.g. `http://ml-service:8000` in Docker, or `http://localhost:8000` for local dev).

---

## Endpoint reference

### 1. `POST /predict/demand` — Demand Prediction
**When to call:** nightly/hourly batch job to forecast next day's order volume per branch (feeds Menu Throttling + kitchen staffing dashboards).

Request:
```json
{
  "branch_id": 1, "day_of_week": 2, "day_of_month": 15, "month": 6,
  "is_weekend": 0, "seating_capacity": 140, "city": "Chennai",
  "lag_1": 3, "lag_7": 2, "rolling_mean_7": 2.5
}
```
`lag_1`/`lag_7`/`rolling_mean_7` = backend must compute these from your own order history (yesterday's count, same-day-last-week's count, 7-day average) before calling.

Response: `{"predicted_orders": 3.2}`

---

### 2. `POST /predict/waste` — Waste Prediction
**When to call:** end-of-day inventory job, per ingredient per branch.

Request:
```json
{"ingredient_id": 1, "branch_id": 2, "quantity_used": 40, "stock_available": 100,
 "unit_cost_inr": 700, "unit": "kg", "day_of_week": 3, "month": 5}
```
Response: `{"predicted_wastage_quantity": 2.08}`

---

### 3. `POST /predict/service-time` — Service Time Estimation ⭐ (your strongest model)
**When to call:** right when an order is placed — show the customer an ETA immediately.

Request:
```json
{"branch_id": 1, "order_hour": 19, "day_of_week": 5, "is_weekend": 1,
 "order_type": "Dine-In", "payment_method": "Credit Card", "discount_pct": 10,
 "total_amount_inr": 1200, "seating_capacity": 140}
```
Response: `{"predicted_completion_time_minutes": 41.0}`

`order_type` must be exactly `"Dine-In"`, `"Online"`, or `"Takeaway"` (case-sensitive, matches training data).

---

### 4. `POST /detect/order-anomaly` — Stuck Order / Unusual Delay Detection
**When to call:** periodically (e.g. every 5 min) re-check any order still "In Progress" past its predicted completion time from endpoint #3.

Request:
```json
{"order_hour": 19, "day_of_week": 5, "order_type": "Dine-In", "payment_method": "Credit Card",
 "discount_pct": 10, "total_amount_inr": 1200, "completion_time_minutes": 220}
```
Response: `{"is_anomaly": true, "anomaly_score": 0.5684}` — if `is_anomaly` is true, trigger a "stuck order" alert in the dashboard's Priority Alerts panel.

---

### 5. `POST /predict/task-priority` — Task Priority Score (single task)
**When to call:** whenever a task (delivery/assistance/urgent) is created.

Request:
```json
{"task_type": "urgent", "waiting_time_min": 25, "food_age_min": 27, "serving_temp_c": 75,
 "decay_rate_c_per_min": 1.5, "current_food_temp_c": 37.5, "distance_to_table_m": 10,
 "robot_battery_pct": 80, "robot_moving": 1, "ble_position_confidence": 0.9,
 "table_urgency": 2, "manager_manual_priority": 0, "urgency_flag": 1}
```
Response: `{"priority_score": 63.0, "priority_tier": "Medium"}`

**Note:** several fields (`current_food_temp_c`, `robot_battery_pct`, `ble_position_confidence`) require real sensor hardware — until deployed, backend can send reasonable placeholder/estimated values, or the ML team will provide a fallback-estimation function.

### 5b. `POST /rerank/tasks` — Real-Time Re-Ranking
**When to call:** any time the pending task queue changes (new task arrives, robot state updates) — send the ENTIRE current queue, get it back sorted.

Request: `{"tasks": [ <task object like above>, <task object>, ... ]}`
Response: `{"ranked_tasks": [ <task with priority_score added, highest first>, ... ]}`

---

### 6. `POST /detect/idle-robot` — Idle Robot Detection
**When to call:** periodically (e.g. every 15 min) per robot in the fleet.

Request:
```json
{"robot_id": 3, "hour": 14, "battery_pct": 50, "pending_tasks_in_branch": 5, "idle_streak_snapshots": 12}
```
Response: `{"robot_id": 3, "is_stuck_or_idle_anomaly": true, "anomaly_score": 0.61}`

**Precision caveat for backend:** this model has ~38% precision (per our metrics) — meaning roughly 2 of every 3 flags are false alarms. Recommend surfacing flags as a dashboard notification for staff review, not an automatic robot-recall action.

---

### 7. `POST /assistant/chat` — Guest Assistant (Intent Detection + Response)
**When to call:** every guest chat message, in real time.

Request: `{"message": "hey where is my order"}`
Response:
```json
{"detected_intent": "order_status", "confidence": 0.72, "response": "Let me check that for you...",
 "low_confidence_warning": false}
```
If `low_confidence_warning` is true (confidence < 0.5), backend should route to a human staff member instead of showing the auto-response.

---

### 8. `POST /analyze/sentiment` — Feedback Sentiment Analysis
**When to call:** when a guest submits feedback with free text.

Request: `{"comment_text": "the food was cold and service was slow"}`
Response: `{"sentiment": "negative", "confidence": 0.55, "low_confidence_warning": false}`

**⚠️ Important caveat for backend team:** this model was trained on synthetic text and misclassified a real test sentence during our own testing. Recommend: (a) still show the manager-facing `rating` number as the primary signal, (b) treat this model's output as a secondary/experimental flag only, (c) don't auto-trigger any customer-facing action off this alone until retrained on real feedback text.

---

### 9. `POST /decide/menu-throttle` — Predictive Menu Throttling
**When to call:** after calling `/predict/demand`, feed its output straight in.

Request: `{"predicted_orders": 45, "seating_capacity": 140}`
Response: `{"action": "NORMAL", "load_pct": 35.7}` — `action` is one of `NORMAL`, `WARN`, `THROTTLE`.

---

## General integration notes for the backend engineer

1. **All endpoints are synchronous POST with JSON body/response** — standard REST, works with any HTTP client (axios, fetch, requests, etc.)
2. **Latency:** each call is a single scikit-learn `.predict()` — expect single-digit milliseconds per call, well within normal API SLAs. No GPU needed.
3. **Errors:** endpoints return HTTP 422 automatically (via FastAPI/Pydantic) if required fields are missing or wrong type — validate against the schemas above before sending.
4. **Batch calls:** all endpoints currently take one record at a time except `/rerank/tasks`. If you need bulk demand/waste predictions (e.g. all 29 branches at once), let the ML team know — easy to add a batch variant.
5. **Model updates:** when the ML team retrains a model, only the `.joblib` file in `models/` changes — restart the service, no backend code changes needed, **as long as the request schema doesn't change**. If a schema does change, that's a versioned API contract change we'll communicate explicitly.
6. **Confidence/precision caveats matter** — endpoints 6 and 8 have documented reliability limits above. Please build in a "flag for human review" path rather than fully automating decisions from these two specifically.
